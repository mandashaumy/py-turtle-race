import turtle
import random
import time

__Pen = turtle.Pen()


#Get start with Python
screen = turtle.Screen()
screen.setup(width=600, height=600)
screen.bgpic("gradient.png")
__Pen.pencolor('#F6F4EB')
__Pen.speed(10)
__Pen.left(90)
while True:
    __Pen.pensize(random.randint(1, 5))
    __Pen.penup()
    __Pen.goto(random.randint((-250), 250), random.randint((-250), 250))
    __Pen.pendown()
    for __count in range(6):
        __Pen.forward(50)
        for __count in range(2):
            __Pen.backward(15)
            __Pen.left(60)
            __Pen.forward(15)
            __Pen.backward(15)
            __Pen.right(120)
            __Pen.forward(15)
            __Pen.backward(15)
            __Pen.left(60)
        __Pen.backward(20)
        __Pen.right(60)
turtle.done()
